# RENCE — A Wanderer With No Corners

A polished static personal-blog starter with a public homepage, reflection pages, places, feedback form UI, donation QR area, and a private-looking admin dashboard.

## Current version
This package is **demo mode**. The admin uses browser `localStorage` and a demo login so the site can be opened immediately on GitHub Pages/Netlify without a backend.

### Demo admin
Open `/admin.html`, enter any non-empty email and password, and manage reflections, places, and image URLs. Data is stored in that browser only.

## Production upgrade
For a real multi-device admin, replace the demo authentication/storage with Supabase:
- Supabase Auth for administrator login
- Postgres tables for posts, places, settings, feedback
- Supabase Storage for uploaded images/QR codes
- Row Level Security policies so only the admin can create/update/delete content

Do **not** put a real admin password in HTML or JavaScript.

## Deployment
Upload the folder to Netlify or GitHub Pages. `index.html` is the public homepage.
